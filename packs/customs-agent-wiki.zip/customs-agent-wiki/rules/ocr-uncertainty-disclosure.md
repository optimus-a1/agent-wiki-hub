---
title: "OCR Uncertainty Disclosure"
wiki: "customs-agent-wiki"
type: rule
status: stable-general-knowledge
source_status: model-synthesized-stable
current_fact: false
requires_source_review: false
requires_human_review: true
risk_level: medium
generated_by: codex
generated_on: 2026-06-15
agent_use: true
tags:
  - agent-wiki
  - stable-knowledge
---

# OCR Uncertainty Disclosure

## Purpose
This page gives agents a stable rule pattern for ocr uncertainty disclosure in `customs-agent-wiki`. It is model-synthesized stable knowledge, not an authoritative source and not a current-fact record.

## Stable Knowledge
- OCR Uncertainty Disclosure should be handled as rule knowledge that supports repeatable agent behavior.
- Document review depends on field provenance, normalization, and cross-document consistency.
- Missing or uncertain values must remain explicit instead of being guessed.
- Amounts, currencies, quantities, weights, parties, and goods descriptions need reconciliation.
- Regulatory conclusions require dated source review and human confirmation.
- The agent should name assumptions, confidence, unknowns, and escalation criteria.
- Changing facts must remain outside stable pages and move through source review.

## Agent Use
- Read this page after the wiki `AGENTS.md`, `rules/`, and relevant workflow pages.
- Use it to structure reasoning, extraction, review, triage, or drafting.
- Keep the final output scoped to stable principles, observable inputs, and user-provided context.
- When evidence is incomplete, report the gap and propose a review step instead of filling it silently.

## Boundaries
- Do not write current facts, current prices, current versions, current rules, live policy, or real-world status.
- Do not present this page as an authoritative source.
- Do not bypass professional, compliance, security, production, financial, legal, medical, customs, or wallet-safety review.
- Do not use this page to justify irreversible action.

## Human Gate
Require human confirmation before filing, declaring, classifying goods, accepting a high-risk discrepancy, or replacing a missing document field.

## Source Gate
HS codes, tax rates, supervision conditions, port rules, customs policy, and regulatory requirements require source review before use.

## Examples
- Use ocr uncertainty disclosure to convert a vague request into explicit fields, checks, and boundaries.
- Use ocr uncertainty disclosure as a checklist item before the agent produces a final answer.
- Use ocr uncertainty disclosure during review to separate supported observations from unresolved risks.
- Use ocr uncertainty disclosure to decide whether a human gate or source gate is required.

## Anti-Patterns
- Treating ocr uncertainty disclosure as permission to invent missing details.
- Replacing uncertainty with confident wording because the output looks cleaner.
- Skipping human review when the action can affect money, rights, health, security, production, or compliance.
- Using stale or unsourced claims as if they were verified current facts.

## Checklist
- Confirm the request matches this wiki and this page type.
- Confirm the output is educational, operational, or review-oriented rather than a current fact claim.
- Preserve unknowns, confidence limits, and evidence gaps.
- Apply the human gate when a high-impact action or professional judgment is involved.
- Apply the source gate when a claim depends on current external information.
