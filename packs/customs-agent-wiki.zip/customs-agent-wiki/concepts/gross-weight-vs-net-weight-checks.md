---
title: "Gross Weight Vs Net Weight Checks"
wiki: "customs-agent-wiki"
type: concept
status: stable-general-knowledge
source_status: model-synthesized-stable
current_fact: false
requires_source_review: false
requires_human_review: true
risk_level: medium
generated_by: codex
generated_on: 2026-06-15
agent_use: true
tags:
  - agent-wiki
  - stable-knowledge
---

# Gross Weight Vs Net Weight Checks

## Purpose
This page gives agents a stable concept pattern for gross weight vs net weight checks in `customs-agent-wiki`. It is model-synthesized stable knowledge, not an authoritative source and not a current-fact record.

## Stable Knowledge
- Gross Weight Vs Net Weight Checks should be handled as concept knowledge that supports repeatable agent behavior.
- Document review depends on field provenance, normalization, and cross-document consistency.
- Missing or uncertain values must remain explicit instead of being guessed.
- Amounts, currencies, quantities, weights, parties, and goods descriptions need reconciliation.
- Regulatory conclusions require dated source review and human confirmation.
- The agent should name assumptions, confidence, unknowns, and escalation criteria.
- Changing facts must remain outside stable pages and move through source review.

## Agent Use
- Read this page after the wiki `AGENTS.md`, `rules/`, and relevant workflow pages.
- Use it to structure reasoning, extraction, review, triage, or drafting.
- Keep the final output scoped to stable principles, observable inputs, and user-provided context.
- When evidence is incomplete, report the gap and propose a review step instead of filling it silently.

## Boundaries
- Do not write current facts, current prices, current versions, current rules, live policy, or real-world status.
- Do not present this page as an authoritative source.
- Do not bypass professional, compliance, security, production, financial, legal, medical, customs, or wallet-safety review.
- Do not use this page to justify irreversible action.

## Human Gate
Require human confirmation before filing, declaring, classifying goods, accepting a high-risk discrepancy, or replacing a missing document field.

## Source Gate
HS codes, tax rates, supervision conditions, port rules, customs policy, and regulatory requirements require source review before use.

## Examples
- Use gross weight vs net weight checks to convert a vague request into explicit fields, checks, and boundaries.
- Use gross weight vs net weight checks as a checklist item before the agent produces a final answer.
- Use gross weight vs net weight checks during review to separate supported observations from unresolved risks.
- Use gross weight vs net weight checks to decide whether a human gate or source gate is required.

## Anti-Patterns
- Treating gross weight vs net weight checks as permission to invent missing details.
- Replacing uncertainty with confident wording because the output looks cleaner.
- Skipping human review when the action can affect money, rights, health, security, production, or compliance.
- Using stale or unsourced claims as if they were verified current facts.

## Checklist
- Confirm the request matches this wiki and this page type.
- Confirm the output is educational, operational, or review-oriented rather than a current fact claim.
- Preserve unknowns, confidence limits, and evidence gaps.
- Apply the human gate when a high-impact action or professional judgment is involved.
- Apply the source gate when a claim depends on current external information.
